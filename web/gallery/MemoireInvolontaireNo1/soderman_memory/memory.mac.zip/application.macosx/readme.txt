This application was created on Windows, which doesn't
properly support setting files as "executable",
a necessity for applications on Mac OS X.

To fix this, use the Terminal on Mac OS X, and from this
directory, type the following:

chmod +x Memory.app/Contents/MacOS/JavaApplicationStub
