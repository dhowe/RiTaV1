package rita.support;

import rita.RiTaEvent;

public interface RiTaEventListener
{
  public void onRiTaEvent(RiTaEvent re);
}
